package drop.events.swordsmp.mixin;

/**
 * Placeholder class retained because the file previously hosted a mixin. The
 * mixin has been removed, but keeping an empty type avoids re-introducing it via
 * accidental merges.
 */
public final class EntityDimensionsMixin {
	private EntityDimensionsMixin() {
	}
}
